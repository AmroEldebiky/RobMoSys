<!--- This file is generated from the ComponentDatabase.componentDocumentation model --->
<!--- do not modify this file manually as it will by automatically overwritten by the code generator, modify the model instead and re-generate this file --->

# ComponentDatabase Component

![ComponentDatabase-ComponentImage](https://github.com/Servicerobotics-Ulm/ComponentRepository/blob/master/ComponentDatabase/model/ComponentDatabaseComponentDefinition.jpg)


| Metaelement | Documentation |
|-------------|---------------|
| License |  |
| Hardware Requirements |  |
| Purpose |  |



## Service Ports


