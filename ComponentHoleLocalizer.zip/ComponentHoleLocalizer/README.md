<!--- This file is generated from the ComponentHoleLocalizer.componentDocumentation model --->
<!--- do not modify this file manually as it will by automatically overwritten by the code generator, modify the model instead and re-generate this file --->

# ComponentHoleLocalizer Component

![ComponentHoleLocalizer-ComponentImage](https://github.com/Servicerobotics-Ulm/ComponentRepository/blob/master/ComponentHoleLocalizer/model/ComponentHoleLocalizerComponentDefinition.jpg)


| Metaelement | Documentation |
|-------------|---------------|
| License |  |
| Hardware Requirements |  |
| Purpose |  |



## Service Ports


